Welcome to HumHub 
=================

[![Build Status](https://travis-ci.org/humhub/humhub.svg?branch=master)](https://travis-ci.org/humhub/humhub)

HumHub is a flexible open source social network application written in PHP.

- <a href="http://humhub.org" target="_blank">**Homepage & Demo**</a>

- <a href="protected/docs/guide/administration/index.md">Installation & Admin Documentation</a>
- <a href="protected/docs/guide/developer/index.md">Developer Documentation</a>
- <a href="protected/docs/guide/theming/index.md">Theming Documentation</a>


- <a href="protected/docs/license.md">License: Dual license AGPL v3 / Proprietary</a>

