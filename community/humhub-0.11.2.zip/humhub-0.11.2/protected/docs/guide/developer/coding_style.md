Coding Style 
============

Overally rules are based on PSR-2 standard with some minor exceptions and changes. 

