Overview
========

## Getting Started

- HumHub is based on Yii PHP Framework (http://www.yiiframework.com/)
- Check out: [The Definitive Guide to Yii](http://www.yiiframework.com/doc/guide/) 

## Development Mode

- Switch to development mode in ``index.php`` (see inline documentation)
- Disable Caching (Administration -> Settings -> Caching -> None)
