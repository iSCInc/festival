Logging
============

Log Files are stored unter ``protected/runtime/application.log``
