Administration Guide/Notes
===========================


##Installation
- [Requirements](requirements.md)
- [Installation](installation.md)
- [Updating](updating.md)

##Advanced Topics
- [Logging](logging.md)
- [Security](security.md)
- [Console](console.md)
- [Search](search.md)
- [X-Sendfile](xsendfile.md)
- [Timezones](timezones.md)

## More
- [Bundled Software](bundled_software.md)
