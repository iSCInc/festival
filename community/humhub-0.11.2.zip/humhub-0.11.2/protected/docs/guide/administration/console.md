Console
=======

There are also some console helpers available.

Run ``./protected/yiic help`` for a full overview / help.

Make sure /protected/yiic or /protected/yiic.bat are marked as executable.

