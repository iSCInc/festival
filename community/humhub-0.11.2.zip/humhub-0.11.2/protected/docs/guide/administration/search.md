Search 
======

The search lucene index is located under /protected/runtime/searchdb/.

If there are any problems with the search index, you can rebuild it with the command.
``./yiic search_rebuild``

