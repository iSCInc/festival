<?php echo CHtml::image($url, $alt, $htmlOptions);?>
