<?php
class EControllerEvent extends CEvent {
	public $view;
	public $output;
	public $isValid = true;
	public $action;
}
