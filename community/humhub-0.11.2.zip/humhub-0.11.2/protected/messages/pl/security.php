<?php
return array (
  'Global {global} array cleaned using {method} method.' => 'Globalna tablica {global} została wyczyszczona używając metody {method}.',
);
