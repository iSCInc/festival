<?php
return array (
  '<strong>Upload</strong> error' => 'Błąd <strong>wczytywania</strong>',
  'Close' => 'Zamknij',
);
