<?php
return array (
  'Global {global} array cleaned using {method} method.' => 'Globální pole {global} bylo vyčištěno pomocí metody {method}.',
);
