<?php
return array (
  '<strong>Login</strong> required' => 'Giriş Yapınız',
);
