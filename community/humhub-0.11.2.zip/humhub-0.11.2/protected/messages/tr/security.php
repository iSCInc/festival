<?php
return array (
  'Global {global} array cleaned using {method} method.' => 'Küresel {global} dizi yöntemi {method} ile temizlenmelidir.',
);
