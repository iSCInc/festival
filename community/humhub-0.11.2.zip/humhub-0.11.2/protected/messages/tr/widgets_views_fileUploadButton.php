<?php
return array (
  '<strong>Upload</strong> error' => '<strong>Yükleme</strong> hatası',
  'Close' => 'Kapat',
);
