<?php
return array (
  'Global {global} array cleaned using {method} method.' => 'S\'ha netejat la cadena {global} utilitzant el mètode {method}.',
);
