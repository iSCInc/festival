<?php
return array (
  '<strong>Upload</strong> error' => '',
  'Close' => 'Lukk',
);
