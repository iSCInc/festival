<?php
return array (
  '<strong>Upload</strong> error' => '',
  'Close' => '关闭',
);
