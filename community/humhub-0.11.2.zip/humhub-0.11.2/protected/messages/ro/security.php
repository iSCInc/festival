<?php
return array (
  'Global {global} array cleaned using {method} method.' => 'Seria {global} globală a fost curățată folosind metoda {method}.',
);
