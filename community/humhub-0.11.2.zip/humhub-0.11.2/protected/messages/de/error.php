<?php
return array (
  '<strong>Login</strong> required' => '<strong>Anmelden</strong> erforderlich',
);
