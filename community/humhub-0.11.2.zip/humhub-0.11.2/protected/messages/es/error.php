<?php
return array (
  '<strong>Login</strong> required' => 'Es necesario <strong>iniciar sesión</strong>',
);
