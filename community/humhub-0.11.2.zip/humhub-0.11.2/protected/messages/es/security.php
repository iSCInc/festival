<?php
return array (
  'Global {global} array cleaned using {method} method.' => 'Se ha limpiado el array {global} usando el método {method}',
);
