<?php
return array (
  '<strong>Upload</strong> error' => 'Error en la <strong>subida</strong>',
  'Close' => 'Cerrar',
);
