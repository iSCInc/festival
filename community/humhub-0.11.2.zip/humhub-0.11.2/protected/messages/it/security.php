<?php
return array (
  'Global {global} array cleaned using {method} method.' => 'L\'array globale {global} è stato cancellato usando il metodo {method}.',
);
