<?php
return array (
  '<strong>Upload</strong> error' => 'Errore durante il <strong>caricamento</strong>',
  'Close' => 'Chiudi',
);
