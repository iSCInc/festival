<?php
return array (
  '<strong>Upload</strong> error' => 'Erro ao enviar arquivo',
  'Close' => 'Fechar',
);
