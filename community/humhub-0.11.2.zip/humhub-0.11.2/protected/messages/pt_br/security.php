<?php
return array (
  'Global {global} array cleaned using {method} method.' => 'O array global {global} foi limpo utilizando o método {method}.',
);
