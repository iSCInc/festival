<?php
return array (
  'Global {global} array cleaned using {method} method.' => '@Global {global} array cleaned using {method} method.@',
);
