<?php
return array (
  '<strong>Login</strong> required' => 'يجب عليك <strong>تسجيل الدخول</strong> ',
);
