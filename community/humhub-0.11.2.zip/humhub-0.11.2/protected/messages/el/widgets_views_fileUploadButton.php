<?php
return array (
  '<strong>Upload</strong> error' => '<strong>Το ανέβασμα</strong> απέτυχε',
  'Close' => 'Κλείσιμο',
);
