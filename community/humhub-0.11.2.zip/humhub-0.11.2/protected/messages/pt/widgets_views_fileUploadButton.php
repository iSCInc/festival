<?php
return array (
  '<strong>Upload</strong> error' => 'Erro ao <strong>Actualizar</strong>',
  'Close' => 'Fechar',
);
