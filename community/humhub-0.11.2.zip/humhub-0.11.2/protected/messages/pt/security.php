<?php
return array (
  'Global {global} array cleaned using {method} method.' => 'Array global {global} limpa usando este método {method}',
);
