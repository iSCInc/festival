<?php
return array (
  '<strong>Login</strong> required' => '<strong>требуется</strong> логин',
);
