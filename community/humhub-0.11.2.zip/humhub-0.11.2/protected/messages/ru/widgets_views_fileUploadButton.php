<?php
return array (
  '<strong>Upload</strong> error' => '<strong>Ошибка</strong> при загрузке',
  'Close' => 'Закрыть',
);
