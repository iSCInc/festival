<?php
return array (
  '<strong>Upload</strong> error' => '<strong>การอัพโหลด</strong> ผิดพลาด',
  'Close' => 'ปิด',
);
