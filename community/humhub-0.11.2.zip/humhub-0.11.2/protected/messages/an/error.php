<?php
return array (
  '<strong>Login</strong> required' => '',
);
