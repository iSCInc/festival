<?php
return array (
  'Global {global} array cleaned using {method} method.' => 'グローバル {global} 配列は、{method} 法を用いて最適化。',
);
