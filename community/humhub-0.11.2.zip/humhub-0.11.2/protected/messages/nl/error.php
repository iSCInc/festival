<?php
return array (
  '<strong>Login</strong> required' => '<strong>Inloggen</strong> vereist',
);
