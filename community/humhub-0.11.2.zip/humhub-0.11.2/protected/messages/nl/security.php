<?php
return array (
  'Global {global} array cleaned using {method} method.' => 'Globale {global} array opgeruimd met de {method} methode.',
);
