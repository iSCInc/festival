<?php
return array (
  '<strong>Upload</strong> error' => '<strong>Upload</strong> fout',
  'Close' => 'Sluiten',
);
