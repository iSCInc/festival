<?php
return array (
  '<strong>Upload</strong> error' => 'Erreur de <strong>Chargement</strong>',
  'Close' => 'Fermer',
);
