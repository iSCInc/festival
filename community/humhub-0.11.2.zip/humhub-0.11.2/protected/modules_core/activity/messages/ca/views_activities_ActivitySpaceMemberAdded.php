<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName% s\'ha unit a l\'espai %spaceName%',
  '%displayName% joined this space.' => '%displayName% s\'ha unit a aquest espai.',
);
