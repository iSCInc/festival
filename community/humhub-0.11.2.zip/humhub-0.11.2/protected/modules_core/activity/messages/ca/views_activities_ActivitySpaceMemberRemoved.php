<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% ha deixat l\'espai %spaceName%',
  '%displayName% left this space.' => '%displayName% ha deixat aquest espai.',
);
