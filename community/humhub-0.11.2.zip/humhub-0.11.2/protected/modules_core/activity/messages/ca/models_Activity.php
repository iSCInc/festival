<?php
return array (
  'Could not create activity for this object type!' => 'No s\'ha pogut crear activitat per aquest objecte!',
);
