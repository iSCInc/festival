<?php
return array (
  'see online' => 'veure en línia',
  'via' => 'via',
);
