<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% utworzył nową strefę %spaceName%',
  '%displayName% created this space.' => '%displayName% utworzył tę strefę.',
);
