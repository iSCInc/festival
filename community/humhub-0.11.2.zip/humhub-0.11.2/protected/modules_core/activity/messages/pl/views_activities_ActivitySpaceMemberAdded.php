<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName% dołączył do strefy %spaceName%',
  '%displayName% joined this space.' => '%displayName% dołączył do tej strefy. ',
);
