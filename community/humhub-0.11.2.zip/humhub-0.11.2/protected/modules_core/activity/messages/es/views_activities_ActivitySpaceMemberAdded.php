<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName% se unió al espacio %spaceName%',
  '%displayName% joined this space.' => '%displayName% se unió a este espacio.',
);
