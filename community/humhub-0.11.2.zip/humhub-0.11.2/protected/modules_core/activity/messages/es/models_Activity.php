<?php
return array (
  'Could not create activity for this object type!' => '¡No se puede crear una actividad para este tipo de objeto!',
);
