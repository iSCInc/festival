<?php
return array (
  'see online' => 'Ver online',
  'via' => 'en',
);
