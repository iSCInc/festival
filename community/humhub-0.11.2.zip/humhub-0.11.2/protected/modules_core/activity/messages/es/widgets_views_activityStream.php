<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>Últimas</strong> actividades',
  'There are no activities yet.' => 'No hay actividades todavia.',
);
