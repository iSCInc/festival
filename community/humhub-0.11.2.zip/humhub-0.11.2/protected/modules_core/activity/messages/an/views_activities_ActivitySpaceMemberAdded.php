<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName% s\'unió a o espacio %spaceName%',
  '%displayName% joined this space.' => '%displayName% s\'unió a iste espacio.',
);
