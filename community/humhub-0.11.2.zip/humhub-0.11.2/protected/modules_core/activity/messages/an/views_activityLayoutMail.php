<?php
return array (
  'see online' => 'veyer en linia.',
  'via' => 'vía',
);
