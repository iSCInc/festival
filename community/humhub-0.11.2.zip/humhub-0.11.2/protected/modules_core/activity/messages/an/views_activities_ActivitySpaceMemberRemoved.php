<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% deixó o espacio %spaceName%',
  '%displayName% left this space.' => '%displayName% deixó iste espacio.',
);
