<?php
return array (
  '{user1} now follows {user2}.' => '{user1} agora sigue a {user2}.',
);
