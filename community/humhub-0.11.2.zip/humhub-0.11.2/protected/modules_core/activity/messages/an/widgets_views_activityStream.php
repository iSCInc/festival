<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>Zagueras</strong> actividatz',
  'There are no activities yet.' => 'No i hai actividatz encara.',
);
