<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% creyó o espacio %spaceName%',
  '%displayName% created this space.' => '%displayName% creyó iste espacio.',
);
