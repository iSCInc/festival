<?php
return array (
  'Could not create activity for this object type!' => 'Non è possibile creare un\'attività per questo tipo di oggetto!',
);
