<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName% si è aggiunto allo space %spaceName%',
  '%displayName% joined this space.' => '%displayName% si è aggiunto a questo space.',
);
