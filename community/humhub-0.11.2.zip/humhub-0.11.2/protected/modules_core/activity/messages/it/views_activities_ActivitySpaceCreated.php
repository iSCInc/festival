<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% ha creato il nuovo space %spaceName%',
  '%displayName% created this space.' => '%displayName% ha creato questo space.',
);
