<?php
return array (
  'see online' => 'vedi online',
  'via' => 'via',
);
