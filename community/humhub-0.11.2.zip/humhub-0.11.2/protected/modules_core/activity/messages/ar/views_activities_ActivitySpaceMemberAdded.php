<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName% قام بالإنضمام إلى الباحة %spaceName%',
  '%displayName% joined this space.' => '%displayName% قام بالإنضمام لهذه الباحة.',
);
