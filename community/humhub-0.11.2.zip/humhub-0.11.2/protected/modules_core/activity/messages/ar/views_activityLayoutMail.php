<?php
return array (
  'see online' => 'مشاهده على الموقع مباشرة',
  'via' => 'بواسطة',
);
