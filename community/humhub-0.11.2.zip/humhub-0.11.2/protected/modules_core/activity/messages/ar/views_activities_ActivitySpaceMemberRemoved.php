<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% خرج من الباحة %spaceName%',
  '%displayName% left this space.' => '%displayName% قرر الخروج من هذه الباحة',
);
