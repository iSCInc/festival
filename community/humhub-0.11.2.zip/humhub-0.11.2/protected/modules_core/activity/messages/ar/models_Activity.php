<?php
return array (
  'Could not create activity for this object type!' => '@Could not create activity for this object type!@',
);
