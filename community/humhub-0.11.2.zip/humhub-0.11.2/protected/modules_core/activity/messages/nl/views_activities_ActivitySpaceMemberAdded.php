<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName% is lid geworden van ruimte %spaceName%',
  '%displayName% joined this space.' => '%displayName% is van deze ruimte lid geworden.',
);
