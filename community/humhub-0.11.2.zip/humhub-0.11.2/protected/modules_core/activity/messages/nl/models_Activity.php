<?php
return array (
  'Could not create activity for this object type!' => 'Kon geen activiteit voor dit object type maken!',
);
