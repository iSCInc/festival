<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% heeft de ruimte %spaceName% verlaten',
  '%displayName% left this space.' => '%displayName% heeft deze ruimte verlaten.',
);
