<?php
return array (
  'see online' => 'zie online',
  'via' => 'via',
);
