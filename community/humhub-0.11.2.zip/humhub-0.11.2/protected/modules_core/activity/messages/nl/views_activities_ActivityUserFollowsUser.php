<?php
return array (
  '{user1} now follows {user2}.' => '{user1} volgt nu {user2}.',
);
