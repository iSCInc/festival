<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% heeft de nieuwe ruimte %spaceName% aangemaakt',
  '%displayName% created this space.' => '%displayName% heeft deze ruimte aangemaakt.',
);
