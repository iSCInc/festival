<?php
return array (
  'Could not create activity for this object type!' => 'Pro objekt tohoto typu nelze vytvořit aktivitu!',
);
