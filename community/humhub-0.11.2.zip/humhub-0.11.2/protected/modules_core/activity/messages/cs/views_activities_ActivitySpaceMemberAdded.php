<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName% vstoupil(a) do prostoru %spaceName%',
  '%displayName% joined this space.' => '%displayName% vstoupil(a) do tohoto prostoru.',
);
