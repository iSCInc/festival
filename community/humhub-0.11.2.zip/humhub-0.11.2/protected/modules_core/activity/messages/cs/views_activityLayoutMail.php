<?php
return array (
  'see online' => 'otevřít v prohlížeči',
  'via' => 'přes',
);
