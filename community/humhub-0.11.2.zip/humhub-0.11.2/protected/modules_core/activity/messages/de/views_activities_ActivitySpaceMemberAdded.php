<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName% ist dem Space »%spaceName%« beigetreten',
  '%displayName% joined this space.' => '%displayName% ist diesem Space beigetreten.',
);
