<?php
return array (
  'Could not create activity for this object type!' => 'Es konnnte keine Aktivität für diesen Objekttyp erstellt werden!',
);
