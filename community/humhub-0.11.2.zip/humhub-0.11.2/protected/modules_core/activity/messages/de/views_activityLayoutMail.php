<?php
return array (
  'see online' => 'online anzeigen',
  'via' => 'über',
);
