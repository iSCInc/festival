<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% erstellte einen neuen Space »%spaceName%«.',
  '%displayName% created this space.' => '%displayName% hat diesen Space erstellt.',
);
