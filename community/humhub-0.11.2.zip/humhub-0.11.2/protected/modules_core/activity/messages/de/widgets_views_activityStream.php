<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>Letzte</strong> Aktivitäten',
  'There are no activities yet.' => 'Noch keine Aktivitäten.',
);
