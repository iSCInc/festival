<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName%さんは、%spaceName% から退出しました',
  '%displayName% left this space.' => '%displayName%さんが、このスペースから退出しました。',
);
