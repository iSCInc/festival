<?php
return array (
  'see online' => 'オンラインで見る',
  'via' => '経由',
);
