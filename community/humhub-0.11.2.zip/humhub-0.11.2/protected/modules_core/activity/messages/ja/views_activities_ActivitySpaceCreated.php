<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName%さんは、新しいスペース %spaceName% を作成',
  '%displayName% created this space.' => '%displayName%さんが、このスペースを作成しました。',
);
