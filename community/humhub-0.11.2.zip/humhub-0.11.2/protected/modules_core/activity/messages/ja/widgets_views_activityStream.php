<?php
return array (
  '<strong>Latest</strong> activities' => '<strong>Latest</strong> 最近の活動',
  'There are no activities yet.' => 'まだ何の活動もありません。',
);
