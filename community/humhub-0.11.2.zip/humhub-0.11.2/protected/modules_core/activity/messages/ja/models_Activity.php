<?php
return array (
  'Could not create activity for this object type!' => 'このオブジェクトタイプの活動を作成できませんでした！',
);
