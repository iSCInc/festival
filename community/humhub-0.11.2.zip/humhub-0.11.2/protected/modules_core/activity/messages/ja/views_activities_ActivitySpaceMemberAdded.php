<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName%さんは、%spaceName% スペースに参加しました',
  '%displayName% joined this space.' => '%displayName%さんが、このスペースに参加しました。',
);
