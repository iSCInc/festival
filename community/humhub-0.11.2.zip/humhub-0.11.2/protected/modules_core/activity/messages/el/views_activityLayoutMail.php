<?php
return array (
  'see online' => 'δες online',
  'via' => 'από',
);
