<?php
return array (
  'Could not create activity for this object type!' => 'Δεν μπορεί να δημιουργηθεί δραστηριότητα γι\'αυτόν τον τύπο αντικειμένου!',
);
