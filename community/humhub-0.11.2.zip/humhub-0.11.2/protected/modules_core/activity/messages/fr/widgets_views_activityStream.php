<?php
return array (
  '<strong>Latest</strong> activities' => 'Activités <strong>récentes</strong>',
  'There are no activities yet.' => 'Il n\'y a aucune activité récente.',
);
