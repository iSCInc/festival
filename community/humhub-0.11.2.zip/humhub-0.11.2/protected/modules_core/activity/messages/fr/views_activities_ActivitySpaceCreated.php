<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% a créé un nouvel espace %spaceName%',
  '%displayName% created this space.' => 'Espace créé par %displayName%',
);
