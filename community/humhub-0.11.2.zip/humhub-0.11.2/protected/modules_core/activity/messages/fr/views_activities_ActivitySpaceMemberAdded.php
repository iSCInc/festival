<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName% a rejoint l\'espace %spaceName%',
  '%displayName% joined this space.' => '%displayName% a rejoint cet espace.',
);
