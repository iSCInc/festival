<?php
return array (
  '%displayName% left the space %spaceName%' => '%displayName% a quitté l\'espace %spaceName%',
  '%displayName% left this space.' => '%displayName% a quitté cet espace.',
);
