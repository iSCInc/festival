<?php
return array (
  'see online' => 'voir en ligne',
  'via' => 'par',
);
