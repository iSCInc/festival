<?php
return array (
  'Could not create activity for this object type!' => 'Impossible de créer une activité pour ce type d\'objet !',
);
