<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% skabt det nye rum %spaceName%',
  '%displayName% created this space.' => '%displayName% skabte dette rum.',
);
