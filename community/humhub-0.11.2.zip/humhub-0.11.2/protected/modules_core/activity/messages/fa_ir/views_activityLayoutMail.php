<?php
return array (
  'see online' => 'مشاهده‌ی آنلاین',
  'via' => 'توسط',
);
