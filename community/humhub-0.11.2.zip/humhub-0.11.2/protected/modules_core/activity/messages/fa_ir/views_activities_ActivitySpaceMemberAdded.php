<?php
return array (
  '%displayName% joined the space %spaceName%' => '%displayName% به انجمن%spaceName% پیوست.',
  '%displayName% joined this space.' => '%displayName% به این انجمن پیوست.',
);
