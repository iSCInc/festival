<?php
return array (
  '%displayName% created the new space %spaceName%' => '%displayName% انجمن جدید %spaceName% را تولیدکرد.',
  '%displayName% created this space.' => '%displayName% این انجمن را تولیدکرده‌است.',
);
