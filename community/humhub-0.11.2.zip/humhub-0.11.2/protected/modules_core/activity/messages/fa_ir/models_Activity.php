<?php
return array (
  'Could not create activity for this object type!' => 'برای این قسمت فعالیت تولید نشد!',
);
